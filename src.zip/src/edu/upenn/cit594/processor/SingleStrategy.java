package edu.upenn.cit594.processor;

import edu.upenn.cit594.util.Area;

public interface SingleStrategy {
	String calculateOperation(Area location);
}
